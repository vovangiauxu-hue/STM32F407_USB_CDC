﻿#include "usbd_cdc_if.h"
#include "main.h"
#include <string.h>
#include <stdio.h>

extern USBD_HandleTypeDef hUsbDeviceFS;
static uint8_t Rx[512];
static uint8_t Tx[512];

static int8_t CDC_Init_FS(void)
{
  USBD_CDC_SetTxBuffer(&hUsbDeviceFS, Tx, 0);
  USBD_CDC_SetRxBuffer(&hUsbDeviceFS, Rx);
  const char *ready="STM32_READY\r\n";
  USBD_CDC_SetTxBuffer(&hUsbDeviceFS,(uint8_t*)ready,strlen(ready));
  USBD_CDC_TransmitPacket(&hUsbDeviceFS);
  return USBD_OK;
}
static int8_t CDC_DeInit_FS(void){ return USBD_OK; }

static int8_t CDC_Control_FS(uint8_t cmd,uint8_t* pbuf,uint16_t length)
{
  if(cmd==CDC_SET_LINE_CODING){
    uint32_t baud = pbuf[0] | (pbuf[1]<<8) | (pbuf[2]<<16) | (pbuf[3]<<24);
    uint8_t stop  = pbuf[4];
    uint8_t parity= pbuf[5];
    uint8_t bits  = pbuf[6];
    extern UART_HandleTypeDef huart1;
    if(huart1.Instance==USART1){
      huart1.Init.BaudRate=baud;
      huart1.Init.WordLength=(bits==7)?UART_WORDLENGTH_7B:UART_WORDLENGTH_8B;
      huart1.Init.StopBits=(stop==2)?UART_STOPBITS_2:UART_STOPBITS_1;
      huart1.Init.Parity=(parity==1)?UART_PARITY_ODD:(parity==2)?UART_PARITY_EVEN:UART_PARITY_NONE;
      huart1.Init.Mode=UART_MODE_TX_RX;
      huart1.Init.HwFlowCtl=UART_HWCONTROL_NONE;
      huart1.Init.OverSampling=UART_OVERSAMPLING_16;
      HAL_UART_DeInit(&huart1); HAL_UART_Init(&huart1);
    }
  }
  return USBD_OK;
}

static int8_t CDC_Receive_FS(uint8_t* Buf,uint32_t *Len)
{
  USBD_CDC_SetRxBuffer(&hUsbDeviceFS, &Buf[0]);
  USBD_CDC_ReceivePacket(&hUsbDeviceFS);

  uint32_t n=*Len; if(n>=sizeof(Tx)) n=sizeof(Tx)-1; Buf[n]=0;

  if      (strncasecmp((char*)Buf,"ECHO",4)==0){ char msg[128]; snprintf(msg,sizeof(msg),"ECHO OK: %s\r\n",(char*)Buf+5);
    USBD_CDC_SetTxBuffer(&hUsbDeviceFS,(uint8_t*)msg,strlen(msg)); USBD_CDC_TransmitPacket(&hUsbDeviceFS); }
  else if (strncasecmp((char*)Buf,"READ",4)==0){
    const char *frame="DATA_BEGIN\n0123456789ABCDEF\nDATA_END\n";
    USBD_CDC_SetTxBuffer(&hUsbDeviceFS,(uint8_t*)frame,strlen(frame)); USBD_CDC_TransmitPacket(&hUsbDeviceFS); }
  else if (strncasecmp((char*)Buf,"WRITE_BEGIN",11)==0){
    const char *ok="WRITE DONE\r\n";
    USBD_CDC_SetTxBuffer(&hUsbDeviceFS,(uint8_t*)ok,strlen(ok)); USBD_CDC_TransmitPacket(&hUsbDeviceFS); }
  else { USBD_CDC_SetTxBuffer(&hUsbDeviceFS,Buf,*Len); USBD_CDC_TransmitPacket(&hUsbDeviceFS); }

  return USBD_OK;
}

int8_t CDC_Transmit_FS(uint8_t* Buf,uint16_t Len)
{
  if(USBD_CDC_SetTxBuffer(&hUsbDeviceFS,Buf,Len)!=USBD_OK) return USBD_FAIL;
  return USBD_CDC_TransmitPacket(&hUsbDeviceFS);
}
