﻿STM32F407_USB_CDC_FULL — Hướng dẫn nhanh
1) Trong STM32CubeIDE 1.19.0: tạo project STM32F407VG (board Discovery), bật USB_DEVICE: CDC, USB_OTG_FS: Device_Only, clock 168MHz (PLLM=8, PLLN=336, PLLP=2, PLLQ=7).
2) Generate code (để IDE tạo Drivers/Middlewares).
3) Đóng project → chép đè các file trong thư mục này vào đúng đường dẫn dự án.
4) Mở lại project → Clean → Build → Nạp → COM xuất hiện → Python thấy 'STM32_READY'.
