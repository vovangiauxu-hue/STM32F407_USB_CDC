﻿#include "main.h"
#include "usb_device.h"
#include <string.h>

UART_HandleTypeDef huart1;

static void SystemClock_Config(void);
static void MX_GPIO_Init(void);
__attribute__((weak)) void MX_USART1_UART_Init(void) {} // nếu chưa bật USART1 trong .ioc vẫn build OK

int main(void)
{
  HAL_Init();
  SystemClock_Config();   // 168MHz, PLLQ=7 -> 48MHz USB
  MX_GPIO_Init();
  MX_USART1_UART_Init();  // nếu có USART1 thì init, không có thì stub trống
  MX_USB_DEVICE_Init();
  while(1){ HAL_Delay(50); }
}

static void SystemClock_Config(void)
{
  RCC_OscInitTypeDef RCC_OscInitStruct={0};
  RCC_ClkInitTypeDef RCC_ClkInitStruct={0};
  __HAL_RCC_PWR_CLK_ENABLE();
  __HAL_PWR_VOLTAGESCALING_CONFIG(PWR_REGULATOR_VOLTAGE_SCALE1);

  RCC_OscInitStruct.OscillatorType=RCC_OSCILLATORTYPE_HSE;
  RCC_OscInitStruct.HSEState=RCC_HSE_ON;
  RCC_OscInitStruct.PLL.PLLState=RCC_PLL_ON;
  RCC_OscInitStruct.PLL.PLLSource=RCC_PLLSOURCE_HSE;
  RCC_OscInitStruct.PLL.PLLM=8;
  RCC_OscInitStruct.PLL.PLLN=336;
  RCC_OscInitStruct.PLL.PLLP=RCC_PLLP_DIV2;
  RCC_OscInitStruct.PLL.PLLQ=7;
  if(HAL_RCC_OscConfig(&RCC_OscInitStruct)!=HAL_OK) Error_Handler();

  RCC_ClkInitStruct.ClockType=RCC_CLOCKTYPE_HCLK|RCC_CLOCKTYPE_SYSCLK|RCC_CLOCKTYPE_PCLK1|RCC_CLOCKTYPE_PCLK2;
  RCC_ClkInitStruct.SYSCLKSource=RCC_SYSCLKSOURCE_PLLCLK;
  RCC_ClkInitStruct.AHBCLKDivider=RCC_SYSCLK_DIV1;
  RCC_ClkInitStruct.APB1CLKDivider=RCC_HCLK_DIV4;
  RCC_ClkInitStruct.APB2CLKDivider=RCC_HCLK_DIV2;
  if(HAL_RCC_ClockConfig(&RCC_ClkInitStruct, FLASH_LATENCY_5)!=HAL_OK) Error_Handler();
}

static void MX_GPIO_Init(void)
{
  __HAL_RCC_GPIOA_CLK_ENABLE();
  __HAL_RCC_GPIOB_CLK_ENABLE();
}

void Error_Handler(void){ __disable_irq(); while(1){} }
