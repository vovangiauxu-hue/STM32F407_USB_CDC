﻿#include "usbd_core.h"
#include "usbd_desc.h"
#include "usbd_conf.h"

#define USBD_VID 0x0483
#define USBD_PID_FS 22336
#define USBD_LANGID_STRING 1033
#define USBD_MANUFACTURER_STRING "STMicroelectronics"
#define USBD_PRODUCT_STRING_FS "STM32 Virtual ComPort"
#define USBD_CONFIGURATION_STRING_FS "CDC Config"
#define USBD_INTERFACE_STRING_FS "CDC Interface"

USBD_DescriptorsTypeDef FS_Desc={
  USBD_FS_DeviceDescriptor, USBD_FS_LangIDStrDescriptor, USBD_FS_ManufacturerStrDescriptor,
  USBD_FS_ProductStrDescriptor, USBD_FS_SerialStrDescriptor, USBD_FS_ConfigStrDescriptor,
  USBD_FS_InterfaceStrDescriptor
};

static uint8_t USBD_FS_DeviceDesc[USB_LEN_DEV_DESC]={
  0x12,USB_DESC_TYPE_DEVICE,0x00,0x02,0x02,0x02,0x00,USB_MAX_EP0_SIZE,
  LOBYTE(USBD_VID),HIBYTE(USBD_VID), LOBYTE(USBD_PID_FS),HIBYTE(USBD_PID_FS),
  0x00,0x02, USBD_IDX_MFC_STR,USBD_IDX_PRODUCT_STR,USBD_IDX_SERIAL_STR, USBD_MAX_NUM_CONFIGURATION
};

uint8_t *USBD_FS_DeviceDescriptor(USBD_SpeedTypeDef speed,uint16_t *len){ *len=sizeof(USBD_FS_DeviceDesc); return USBD_FS_DeviceDesc; }

uint8_t *USBD_FS_LangIDStrDescriptor(USBD_SpeedTypeDef speed,uint16_t *length){
  static __ALIGN_BEGIN uint8_t desc[] __ALIGN_END = {4, USB_DESC_TYPE_STRING, LOBYTE(USBD_LANGID_STRING), HIBYTE(USBD_LANGID_STRING)};
  *length = 4; return desc;
}

static uint8_t strBuf[USBD_MAX_STR_DESC_SIZ];
uint8_t *USBD_FS_ProductStrDescriptor(USBD_SpeedTypeDef speed, uint16_t *length){ USBD_GetString((uint8_t*)USBD_PRODUCT_STRING_FS,strBuf,length); return strBuf; }
uint8_t *USBD_FS_ManufacturerStrDescriptor(USBD_SpeedTypeDef speed, uint16_t *length){ USBD_GetString((uint8_t*)USBD_MANUFACTURER_STRING,strBuf,length); return strBuf; }
uint8_t *USBD_FS_ConfigStrDescriptor(USBD_SpeedTypeDef speed, uint16_t *length){ USBD_GetString((uint8_t*)USBD_CONFIGURATION_STRING_FS,strBuf,length); return strBuf; }
uint8_t *USBD_FS_InterfaceStrDescriptor(USBD_SpeedTypeDef speed, uint16_t *length){ USBD_GetString((uint8_t*)USBD_INTERFACE_STRING_FS,strBuf,length); return strBuf; }
uint8_t *USBD_FS_SerialStrDescriptor(USBD_SpeedTypeDef speed, uint16_t *length){ USBD_GetString((uint8_t*)"F407-USB-CDC",strBuf,length); return strBuf; }
